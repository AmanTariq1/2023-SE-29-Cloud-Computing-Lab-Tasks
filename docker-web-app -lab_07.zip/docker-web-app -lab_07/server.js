const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API Route 1 - App Info
app.get('/api/info', (req, res) => {
    res.json({
        app: "Docker Web App",
        student: "Aman Tariq",
        rollNo: "2023-SE-29",
        labTask: "Lab Task 07 - Dockerfile",
        containerized: true,
        platform: "Docker Desktop",
        timestamp: new Date().toISOString(),
        status: "App is running inside a Docker container! 🐳"
    });
});

// API Route 2 - System Info (shows container internals)
app.get('/api/system', (req, res) => {
    const os = require('os');
    res.json({
        hostname: os.hostname(),
        platform: os.platform(),
        architecture: os.arch(),
        nodeVersion: process.version,
        uptime: `${Math.floor(process.uptime())} seconds`,
        memory: `${Math.round(os.freemem() / 1024 / 1024)} MB free`,
        message: "This is a real containerized environment running on Docker!"
    });
});

// API Route 3 - Greeting
app.get('/api/greet/:name', (req, res) => {
    res.json({
        message: `Hello ${req.params.name}! Welcome to my Dockerized app.`,
        deployedBy: "Aman Tariq (2023-SE-29)",
        container: "docker-web-app"
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🐳 Server is running on port ${PORT}`);
    console.log(`📍 Access it at http://localhost:${PORT}`);
});