const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API Route - Returns student info
app.get('/api/info', (req, res) => {
    res.json({
        name: "Aman Tariq",
        rollNo: "2023-SE-29",
        subject: "Cloud Computing (SE-3202)",
        labTask: "Lab Task 05 - Backend Deployment",
        platform: "Render",
        timestamp: new Date().toISOString(),
        status: "Backend is working perfectly! 🚀"
    });
});

// API Route - Greeting
app.get('/api/greet/:name', (req, res) => {
    const userName = req.params.name;
    res.json({
        message: `Hello ${userName}! Welcome to my backend server.`,
        server: "Render.com",
        deployedBy: "Aman Tariq (2023-SE-29)"
    });
});

// Serve the homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`✅ Server is running on port ${PORT}`);
});