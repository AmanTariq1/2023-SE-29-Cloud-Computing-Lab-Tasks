const express = require('express');
const path = require('path');
const os = require('os');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Simple in-memory counter (Redis optional)
let visitCount = 0;

// API Route 1 - App Info
app.get('/api/info', (req, res) => {
    visitCount++;
    res.json({
        app: "Docker Web App",
        student: "Aman Tariq",
        rollNo: "2023-SE-29",
        labTask: "Lab Task 08 - Docker Compose",
        containerized: true,
        visitCount: visitCount,
        services: {
            web: "running",
            redis: process.env.REDIS_HOST || "redis"
        },
        status: "App is running with Docker Compose! 🐳"
    });
});

// API Route 2 - System Info
app.get('/api/system', (req, res) => {
    res.json({
        hostname: os.hostname(),
        platform: os.platform(),
        architecture: os.arch(),
        nodeVersion: process.version,
        uptime: `${Math.floor(process.uptime())} seconds`,
        memory: `${Math.round(os.freemem() / 1024 / 1024)} MB free`,
        redisHost: process.env.REDIS_HOST || "redis",
        redisPort: process.env.REDIS_PORT || "6379",
        message: "This is a multi-container environment running with Docker Compose!"
    });
});

// API Route 3 - Greeting
app.get('/api/greet/:name', (req, res) => {
    res.json({
        message: `Hello ${req.params.name}! Welcome to my multi-container app.`,
        deployedBy: "Aman Tariq (2023-SE-29)",
        services: ["web", "redis"],
        orchestration: "Docker Compose"
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🐳 Server is running on port ${PORT}`);
    console.log(`📍 Access it at http://localhost:${PORT}`);
    console.log(`🔗 Redis host: ${process.env.REDIS_HOST || 'redis'}`);
});